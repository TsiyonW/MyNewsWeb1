/*
    *   Tsiyon Wuletaw
    *   section 2 SE
    *   ATR/0672/08
*/
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

public class MyNewsWeb {

    WebDriver driver = new ChromeDriver();

    public void metod1(){
//        driver.get("http://www.bbc.co.uk/news");
        driver.get("http://localhost/Home%20-%20BBC%20Newsfff.php");
        String xpPara = "//p[@class = 'gs-c-promo-summary gel-long-primer gs-u-mt nw-c-promo-summary']";
        String xpLinks = "//h3[@class = 'gs-c-promo-heading__title gel-pica-bold nw-o-link-split__text']";
        List<WebElement> Paragraphs = driver.findElements(By.xpath(xpPara));

        List<WebElement> Links = driver.findElements(By.xpath(xpLinks));



        for(int i =0;i< Paragraphs.size() ; i++){

            WebElement link = Links.get(i);
            WebElement  paragraph = Paragraphs.get(i);
            String zTitle = link.getText();
            String zDetail = paragraph.getText();
            System.out.println(zTitle);
            System.out.println(zDetail);
            driver.get("http://localhost/MyNews/upload.php");
            WebElement Title = driver.findElement(By.id("inputTitle"));
            WebElement Detail = driver.findElement(By.id("inputDetail"));
            WebElement Submit = driver.findElement(By.id("inputSubmit"));


            Title.sendKeys(zTitle);
            Detail.sendKeys(zDetail);

            Submit.click();
            driver.get("http://localhost/MyNews/index.php");
        }

    }

    public static void main(String [] args){
        MyNewsWeb myNewsWeb = new MyNewsWeb();
        myNewsWeb.metod1();

    }
}