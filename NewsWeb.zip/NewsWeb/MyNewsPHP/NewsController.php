<?php


class NewsController extends News{

    public function viewNews(){
        $datas = $this->getNews();
        return $datas;
    }
    public function insertNews($Titlee,$Detaill){
        
        $this->uploadNews($Titlee,$Detaill);
    }
    public function deleteOldNews(){

    }
    

}