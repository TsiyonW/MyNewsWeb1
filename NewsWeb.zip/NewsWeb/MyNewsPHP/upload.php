

<!DOCTYPE html>
<html>

<head>
    <!-- Mobile Specific Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Site Title -->
    <title>Upload News</title>
    <!--
		CSS
		============================================= -->
    <link rel="stylesheet" href="css/linearicons.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/nice-select.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/main.css">
</head>

<body>
    <header>

        <div class="header-top">
        </div>
        <div class="container main-menu" id="main-menu">
            <div class="row align-items-center justify-content-between">
                <nav id="nav-menu-container">
                    <ul class="nav-menu">
                        <li class="menu-active">
                            <a href="index.html">Home</a>
                        </li>
                        <li>
                            <a href="about.html">About</a>
                        </li>
                    </ul>
                </nav>

            </div>
        </div>
    </header>

    <div class="site-main-container">
    
        <section class="latest-post-area pb-120">
            <div class="container no-padding">
                <div class="row">
                    <div class="col-lg-8 post-list">
                        <div class="latest-post-wrap">
                            <h4 class="cat-title">Upload News</h4>
                           
                           <form methd  = "POST" action = "upload.php">
                           <input type = "hidden" name = "submitted" value = "TRUE"/>
                           </br>
                           Title: <input type = "text"  class="form-control" name = "Title" id = "inputTitle"/>
                           </br>
                           Detail:<input type = "text"  class="form-control" name = "Detail" id = "inputDetail"/>
                           </br>
                           <input type="submit" value = "Insert"  class="btn btn-success" id = "inputSubmit"/>
                           
                           </form>
                           
                            

                    

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>


</body>

</html>

<?php

include 'database.php';
include 'News.php';
include 'NewsController.php';


if(isset($_POST['submitted'])){
// echo'here';
$title = $_POST['Title'];
$detail = $_POST['Detail'];
}

$news = new NewsController();
$news->insertNews($title,$detail);
?>