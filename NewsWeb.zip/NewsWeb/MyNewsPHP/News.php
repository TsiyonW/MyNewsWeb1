<?php
class News extends database{
     
    public  function getNews(){
        $sql = "SELECT * FROM News";
        $result = $this->connect()->query($sql);
        $numRows = $result->num_rows;
        if($numRows >0){
            while($row = $result->fetch_assoc()){
                $data[] = $row;
            }
            return $data;

        }
        //return $this->sex;

    }

    public function uploadNews($title,$detail){
        $sql = "INSERT INTO News (Title,Description) VALUES('$title','$detail')";
        if($this->connect()->query($sql)== TRUE){
            echo 'fk;dssssssssssf';
        }
        else{
            echo 'kfsjjjjjjjjjjjjjjj';
        }
        }
 
}